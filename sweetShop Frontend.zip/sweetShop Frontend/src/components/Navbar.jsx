import { Link, useNavigate } from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import './Navbar.css';

const Navbar = () => {
  const { auth, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    
    if (auth?.user?.role === "ADMIN") {
      navigate("/login");
    } else {
      navigate("/");
    }
  };

  // 🔹 Not logged in → Public Navbar
  if (!auth) {
    return (
      <nav>
        <Link to="/home">Home</Link> |{" "}
        <Link to="/login">Login</Link> |{" "}
        <Link to="/register">Register</Link>
      </nav>
    );
  }

  // 🔹 Admin Navbar
  if (auth.user.role === "ADMIN") {
    return (
      <nav>
        <Link to="/admin">Admin Home</Link> |{" "}
        <Link to="/admin/manage-sweets">Manage Sweets</Link> |{" "}
        <button onClick={handleLogout}>Logout</button>
      </nav>
    );
  }

  
  return (
    <nav>
      <Link to="/home">Home</Link> |{" "}
      <Link to="/user/dashboard">Dashboard</Link> |{" "}
      <button onClick={handleLogout}>Logout</button>
    </nav>
  );
};

export default Navbar;