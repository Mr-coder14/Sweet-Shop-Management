import { createContext, useState, useEffect } from "react";
import { verifyToken } from "../api/authUtils";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState(null);
  const [loading, setLoading] = useState(true);

 
  useEffect(() => {
    const initAuth = async () => {
      const { valid, user } = await verifyToken();
      
      if (valid) {
        setAuth({ user });
      } else {
        setAuth(null);
      }
      
      setLoading(false);
    };

    initAuth();
  }, []);

  const login = async (token) => {
    localStorage.setItem("token", token);
    
    // Verify the new token and get user info
    const { valid, user } = await verifyToken();
    
    if (valid) {
      setAuth({ user });
    }
  };

  const logout = () => {
    localStorage.removeItem("token");
    setAuth(null);
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <AuthContext.Provider value={{ auth, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};